
/*! \brief Efficient solution structure

	Each efficient solution in the algorithm is defined by using Efficient structure, and each efficient solution has only one parameter which is objective function value vector. 
*/
struct Efficient
{
	//! Objective value for the \f$ j \f$-th objective function \f$( f_j(x) )\f$.
	int* f;
};




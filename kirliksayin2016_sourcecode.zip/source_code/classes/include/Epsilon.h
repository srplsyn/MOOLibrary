#pragma once

#include <iostream>
#include <deque>
#include <vector>
#include <algorithm>
#include <math.h>

#include "Efficient.h"
#include "Box.h"

#include <ilcplex/ilocplex.h>

using namespace std;

ILOSTLBEGIN
	
/*! \brief \f$ \varepsilon \f$-Constraint Method Class

	In this class, a nondominated set enumeration method is implemented for multiobjective discrete optimization problems with any number of objective functions \f$( p \ge 2) \f$. 
Algorithm searches \f$ (p-1)\f$-dimensional space exhaustively by using  \f$ (p-1)\f$-dimensional rectangles. 
For each rectangle \f$ (R \in L) \f$, two-stage formulation is solved. 
In each iteration rectangle with the largest volume-based measure is picked from the list. Then two-stage formulation is solved with the upper vertex of \f$R_i \f$. Algorithm is terminated when the list \f$ L \f$ is empty. \n
	\f$
	\begin{array}{lll}
         P(u_i) & \min & \displaystyle f_k(x) \\
	\displaystyle & \mbox{s.t.} & f_j(x) \le u_{ij} \quad j=1,\ldots,p and j \neq k\\
	\displaystyle & & x \in \mathcal{X}
	\end{array} \f$ \n
	
	Let \f$ x' \f$ be the optimal solution of \f$ P(u_i) \f$. Second stage optimization problem is as follows. 
	
	\f$ \begin{array}{lll}
	Q(u_i) & \min & \displaystyle \sum_{j=1}^p f_j(x) \\
			\displaystyle & \mbox{s.t.} & f_j(x) \le u_{ij} \quad j=1,\ldots,p and j \neq k\\
			\displaystyle & & f_k(x) \le f_k(x') \\
			\displaystyle & & x \in \mathcal{X}
		\end{array}
	\f$ \n
	Let \f$ x^* \f$ be the optimal solution of the two-stage formulation. \f$ x^* \f$ is an efficient solution and \f$ f(x^*) \in \mathbb{R}^p \f$ is the resulting nondominated solution. 
Depending on the \f$ f(x^*) \f$, three following conditions occur. 
	@section section_toc Possible cases into the method
	<ol>
	<li> \f$ x^* \neq \emptyset \mbox{ and } f(x^*) \nsubseteq Y_N \f$. A new efficient solution is obtained. 
		<ul> 
		<li> updateList \f$\left(k,\; f(x^*) \right)\f$
		<li> removeBox \f$ \left(k, \; R_i, \; f(x^*) \right)\f$
		</ul>
	<li> \f$ x^* \neq \emptyset \mbox{ and } f(x^*) \subseteq Y_N \f$. Obtained efficient solution has already found.
		<ul> 
		<li> removeBox \f$ \left (k, \; R_i, \; f(x^*) \right ) \f$
		</ul> 
	<li> \f$ x^* = \emptyset \f$. Two-stage \f$ P_(u^i) \f$ model returns an infeasible solution for \f$ R_i \f$.
		<ul> 
		<li> removeBox \f$ \left (k, \; R_i, \; y^I \right ) \f$
		</ul> 
	</ol>

*/
class Epsilon {	
 private:
  //! Loop index
  int i;
  //! Loop index 
  int j;
  //! Iterator for the non-dominated points 
  deque<Efficient*>::iterator iteff;
  //! Iterator for the non-dominated points 
  deque<Efficient*>::iterator it;
  //! Iterator for the box array 
  deque<Box*>::iterator itbox;
 protected:
  //! Number of objective functions.
  int p;
  //! Number of models solved.
  int counter;
  //! Number of constraints in \f$ \mathcal{X} \f$.
  int number;
  //! Right hand side tolerance for the \f$ \varepsilon \f$-Constraint formulation.
  int delta;
  //! Number of nondominated solutions
  int numeff;
  //! Environment object
  IloEnv env;
  //! Cplex object
  IloCplex cplex;
  
  //! Set of objective functions \f$ \left ( f_j(x) \quad j=\{1, \ldots, p \} \right )\f$. 
  vector<IloExpr> objs;
  //! All objective function expression \f$ \left ( \displaystyle \sum _{j=1}^p f_j(x) \right ) \f$. 
  IloExpr allobj;
  //! Set of constraints \f$ ( \mathcal{X} )\f$.
  IloConstraintArray cons;

  //! Flag for the efficient solution. True; if a new efficient solution is obtained, false; otherwise.
  bool found;
  //! Set of nondominated solutions \f$ (Y_N) \f$. 
  deque<Efficient*> effset;
  //! Set of rectangles \f$ L \f$ 
  deque<Box*> boxes;
  //! Temporary rectangle set \f$ T \f$ which is used for rectangular subdivision. 
  deque<Box*> T_box;
  //! Number of boxes.
  int sizeb;
  //! Number of boxes in \f$ T \f$.
  int sizet;

  //! Model object for the two-stage formulation.
  IloModel epsmodel;
  //! Objective function for the first and second formulation. \note Objective functions of first and second stage are different (see \f$ P(u_i) \f$ and \f$ Q(u_i) \f$). Hence, \f$ \mathtt{setExpr} \f$ (Cplex library) method is used to modify the objective function. 
  IloObjective objfunc;
  //! Objective function range bounds. \note In each iteration bounds for the objective functions are changing while feasible set \f$ \mathcal{X} \f$ is still same. So that \f$ \mathtt{range\_obj[j]} \f$ is modified by using \f$ \mathtt{setUB} \f$ (Cplex library) method. Initially, bounds for the objective functions are as follows, \f$ y^I_j \le f_j(x) \le y^U_j \quad j=\{1,\ldots,p \}\f$. 
  deque<IloRange> range_obj;	
  //! List of removed rectangle indexes.
  deque<int> liste;
  //! Variable array of the objective functions. List of variables in \f$ f_j(x) \f$ where \f$ j=\{1,\ldots,p\}\f$.
  vector<vector<IloNumVar> > varArray;
  //! Number array of the objective functions. List of variable coefficients in \f$ f_j(x) \f$ where \f$ j=\{1,\ldots,p\}\f$.
  vector<vector<IloNum> > numArray;
  //! Ideal point. \f$ \left ( y^I_j \quad j=\{1,\ldots,p \} \right )\f$. Solution of \f$\left ( \displaystyle \min_{x \in \mathcal{X}} \quad  f_j(x) \right )\f$ problem.
  int* ideal;
  //! Upper limit point for each objective function. \f$ \left ( y^U_j \quad j=\{1,\ldots,p \} \right )\f$. Solution of \f$ \left ( \displaystyle \max_{x \in \mathcal{X}} \quad  f_j(x) \right ) \f$ problem)
  int* upper;
  /*! \brief Determine the rectangle with the largest volume-based measure. 
    
  This function determines the rectangle \f$ R_i \f$ with the largest volume-based measure. \f$ R_i \leftarrow \displaystyle \argmax_{R_s\in L} \{V_s: R_s \rightarrow A_s \} \f$. 
  
  @param[out] box Index of a rectangle with the largest volume-based measure. 
  */
  int findMaxAreaBox();	

	
  /*! \brief Two stage \f$ \varepsilon \f$-constraint formulation
    
  This function solves two-stage \f$ \varepsilon \f$-constraint formulation. 
		
  @param k Objective function index that taken into objective function in the \f$ \varepsilon \f$-constraint formulation.
  @param rhs Upper bounds for the objective functions \f$ \left (f_j(x) \right)\f$ where \f$ \mathtt{rhs[j]} \f$ is defined for \f$ j=\{1,\ldots,p\} \mbox{ and } j \neq k \f$. It should be noted that the size of rhs is \f$ p \f$.
  @param obj Objective function values. Let \f$ x^* \f$ be the optimal solution of the two stage \f$ \varepsilon \f$-constraint formulation. \f$ \mathtt{obj[j]} = f_j(x^*) \quad j=\{1,\ldots,p\}\f$. 
  
  @return True if the model is feasible, false otherwise.
  */
  bool epsilonModel(int k, const int* rhs, int* obj);
	
  /*! \brief Get the multiobjective optimization model parameters
		
  This function imports MODO problem instance via MPS or LP file. The objective function of the MPS or LP file is skipped. First \f$ p \f$ constraints of the model represents objective functions of the problem \f$ (f_j(x)) \f$ for \f$ j=1,\ldots,p\f$. The remaining rows of the model are the constraints, i.e. the feasible set \f$ \mathcal{X} \f$, of the problem. 
		
  @param fileName Name of the mps or lp file. 
  */
  void getParameters(char* fileName);
		
  /*! \brief Control whether a new efficient solution is obtained or not
    
  This function controls whether the input nondominated solution named \f$ \mathtt{obj} \f$ is a new solution or not. If the nondominated solution is new, than \f$ f(x^*) \f$ is added to the list \f$ Y_N \f$ and function return true, else function just returns false.  
  
  @param obj Obtained nondominated solution by using two-stage \f$ \varepsilon \f$-constraint formulation.
  
  @return True if a new nondominated solution is obtained, false nondominated solution has already been found.
  */
  bool checkEfficient(int* obj);
	
  /*! \brief Update the rectangle list \f$ L \f$ considering the new nondominated solution \f$ f(x^*) \f$
    
  In this method, all rectangles in the list are controlled to apply rectangular division process. If \f$ (R_i \rightarrow l_j) < f_j(x^*) < (R_i \rightarrow u_j) \f$, then split the rectangle \f$ R_i \f$ along the \f$ j^{th}\f$ axis. 
		
  @param num Objective function index that taken into objective function in the \f$ \varepsilon \f$-constraint formulation.
  @param obj New nondominated solution. 

  */
  void updateList(int num, int* obj);
  
  /*! \brief Remove the redundant boxes
    
  Remove rectangles that lies on \f$ R(rhs,obj)\f$. In each iteration, this method is called exactly once. If two-stage formulation is feasible than \f$ \mathtt{rhs}_j = R_i \rightarrow u_j \f$ and \f$ \mathtt{obj}_j = f_j(x^*)\f$ for all  \f$ j \in \{1,\ldots,p\}\f$. For the infeasibility case, \f$ \mathtt{rhs}_j = R_i \rightarrow u_j \f$ and \f$ \mathtt{obj}_j = y_j^I \f$ for all \f$ j \in \{1,\ldots,p\}\f$.
		
  @param num Objective function index that taken into objective function in the \f$ \varepsilon \f$-constraint formulation.
  @param rhs Upper vertex of the rectangle that defines the unnecessary search space. 
  @param obj Lower vertex of the rectangle that defines the unnecessary search space.  
  */
  void removeBox(int num, int* rhs, int* obj);
  
  
  /*! \brief Control whether the set of constraints \f$ \mathcal{X} \f$ has a feasible solution
		
  This function controls whether the set of constraints \f$ \mathcal{X} \f$ has a feasible solution. Additionally, in this function boundaries of the initial rectangle are determined. Briefly, the ideal point \f$ y^I \f$ and upper bounds for objective functions \f$ y^U \f$ are determined.
		
  @return True, if set of constraints \f$ \mathcal{X} \;\f$ has a feasible solution, false otherwise.
  */
  bool obtainBounds();
 public:	
  /*! \brief Constructor of the Epsilon class
    
  Parameters (i.e. counter) are set to their initial value. Cplex parameters are initialized. 
  
  @param _p Number of functions	
  */
  Epsilon(int _p);
	
  /*! \brief Destructor of the Epsilon class
    
  This function is the destructor of the Epsilon class. In this function, allocated objects in the constructor class are deallocated. 
  
  */
  ~Epsilon(void);
  
  /*! \brief Main loop of the \f$ \varepsilon \f$-constraint method
		
  Main loop of the \f$ \varepsilon \f$-constraint method, Firstly, model parameters are imported by using getParameters method, than three possible cases (see @ref section_toc) are handled into while loop. When the list \f$ L \f$ is empty, algorithm is terminated. 
		
  @param fileName Name of the mps or lp file. 
  */
  void mainLoop(char* fileName);
};












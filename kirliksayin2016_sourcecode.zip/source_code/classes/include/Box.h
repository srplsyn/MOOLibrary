

/*! \brief Box structure

	Each box in the algorithm is defined by using Box structure, and each box defined by three parameters which are lower boundary, upper boundary and covered area. 
*/
struct Box
{
	//! Lower boundary of \f$ j \f$-th axis in box-\f$ i \f$
	int* l;
	//! Lower boundary of \f$ j \f$-th axis in box-\f$ i \f$
	int* u;
	//! Covered area by box-\f$ i \f$
	float A;
};





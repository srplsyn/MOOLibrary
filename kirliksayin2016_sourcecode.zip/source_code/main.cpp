
#define PRG_NAME "Generating All Nondominated Solutions for Multiobjective Discrete Optimization Problems." 
#define CPY_RGHT "Copyright © 2014" 
#define AUTHOR "Gokhan Kirlik" 

#include "Epsilon.h"

#include <string>
#include <numeric>
#include <deque>

using namespace std;
	
int main(int argc, char** argv)  {	
	
  //number of objective functions
  const int p = 3;
	
  //name of the input file
  char *fileName = new char[150];
  //strcpy(fileName, "KP_p-3_n-20_ins-1.lp");
  strcpy(fileName, "KP_p-3_n-30_ins-1.lp");
  //strcpy(fileName, "KP_p-3_n-40_ins-1.lp");
  std::cout << fileName << std::endl;
  
  //create object
  Epsilon epsilon(p);
  //Call method
  epsilon.mainLoop(fileName); 
			
  return 0;
}
